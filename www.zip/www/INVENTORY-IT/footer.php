</div>
    </div>
    <script src="<?php BASE_URL ?>/js/all.min2.js" crossorigin="anonymous"></script>
    <script src="<?php BASE_URL ?>/js/jquery-3.5.1.slim.min.js" crossorigin="anonymous"></script>
    <script src="<?php BASE_URL ?>/js/bootstrap.bundle.min.js" crossorigin="anonymous"></script>
    <script src="<?php BASE_URL ?>/js/scripts.js"></script>
    <script src="<?php BASE_URL ?>/js/Chart.min.js" crossorigin="anonymous"></script>
    <script src="<?php BASE_URL ?>/assets/demo/chart-area-demo.js"></script>
    <script src="<?php BASE_URL ?>/assets/demo/chart-bar-demo.js"></script>
    <script src="<?php BASE_URL ?>/js/jquery.dataTables.min.js" crossorigin="anonymous"></script>
    <script src="<?php BASE_URL ?>/js/dataTables.bootstrap4.min.js" crossorigin="anonymous"></script>
    <script src="<?php BASE_URL ?>/assets/demo/datatables-demo.js"></script>
    <script src="<?php BASE_URL ?>/js/bootstrap.bundle2.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
    </body>

    </html>