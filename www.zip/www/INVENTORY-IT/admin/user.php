<?php
$title = "User | Elastomix";
require "../BackEnd/function.php";
require "../BackEnd/check_role.php";
include "layout/header.php";

// if(isset($_POST['adduser'])) {
//     $username = mysqli_real_escape_string($conn, $_POST['username']);
//     $departemen = mysqli_real_escape_string($conn, $_POST['$departemen']);
//     $password = mysqli_real_escape_string($conn, $_POST['password']);
//     $role_id = 2;

//     $check_query = "SELECT * FROM user WHERE username = '$username";
//     $checkResult = mysqli_query($conn, $check_query);

//     if (mysqli_num_rows($checkResult) > 0) {
//         echo "<script>alert('Username sudah digunakan! Silahkan gunakan username yang lain.'); window.history.back();<script>";
//         exit();
//     }

//     $hashed_password = md5($password);

//     $query = "INSERT INTO user (username, departemen, password, role_id) VALUES ('$username', '$departemen', '$password', '$role_id')";

//     if (mysqli_query($conn, $query)) {
//         echo "<script>alert('User berhasil ditambahkan!'); window.location.href='user.php';</script>";
//         exit();
//     } else {
//         echo "<script>alert('Terjadi Kesalahan: " . mysqli_error($conn) . " ');</script>";
//         exit();
//     }
// }


?>

<main>
    <div class="container-fluid">
        <h1 class="mt-4">User</h1>
        <!-- Button trigger modal -->
        <!-- <button type="button" style="border-radius: 10px;" class="btn btn-info" data-bs-toggle="modal" data-bs-target="#exampleModal">Tambah Masuk Barang</button> -->
        <div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
            <div class="modal-dialog modal-xl">
                <div class="modal-content">

                    <!-- HEADER -->
                    <div class="modal-header bg-success">
                        <h1 class="modal-title fs-6 text-white" id="exampleModalLabel">Form User</h1>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <!-- HEADER END -->

                    <!-- Modal Body -->
                    <div class="modal-body">
                        <form id="dynamicForm" action="" method="POST">
                            <div class="form-group mb-3 d-flex">
                                <input type="text" name="Nama" placeholder="Username" class="form-control" required>
                                <input type="text" name="Departemen" placeholder="Departemen" class="form-control ms-2">
                                <input type="text" name="Password" placeholder="Password" class="form-control ms-2" required>
                            </div>
                            <div class="text-end"> <button type="submit" class="btn btn-primary " name="adduser">Submit</button></div>
                        </form>
                    </div>
                    <!-- Modal End -->
                </div>
            </div>
        </div>
        <!-- tabel hasil data -->
        <div class="card mb-4">

            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-hover table-striped table-bordered " id="dataTable" width="100%" cellspacing="0">
                        <thead>
                            <tr>
                                <th>NO</th>
                                <th>Nama</th>
                                <th>DEPARTEMEN</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            $query = "SELECT * FROM user";
                            $result = mysqli_query($conn, $query);
                            $i = 1;

                            while ($data = mysqli_fetch_array($result)) {
                                $username = $data['username'];
                                $departemen = $data['departemen'];

                            ?>
                                <tr>
                                    <td><?= $i++; ?></td>
                                    <td><?= $username; ?></td>
                                    <td><?= $departemen ?></td>
                                </tr>
                            <?php
                            };
                            ?>
                        </tbody>
                    </table>
                </div>
            </div>

        </div>
    </div>
</main>
</div>
</div>

<?php include "../footer.php"; ?>