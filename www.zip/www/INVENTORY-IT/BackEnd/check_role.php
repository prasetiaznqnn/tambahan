<?php
session_start();
// Periksa apakah pengguna sudah login
if (!isset($_SESSION['id']) || !isset($_SESSION['role'])) {
    // Jika belum login, arahkan ke halaman login
    header("Location: ../index");
    exit();
}

if ($_SESSION['role'] !== 'admin') {

    header("Location: ../user/index");
    exit();
}
// Jika admin, biarkan proses lanjut
