<?php
$conn = mysqli_connect("localhost", "root", "", "db_inventory_it");

define("BASE_URL", "http://localhost");

if (!$conn) {
    die("Koneksi ke database gagal: " . mysqli_connect_error());
}
//                                                                              <==FORM DI BARANG.PHP==>
if (isset($_POST['addnewbarang'])) {
    // Ambil data dari form
    $kodebarang = $_POST['kodebarang'];
    $jenisbarang = $_POST['jenisbarang'];
    $namabarang = $_POST['namabarang'];
    $dekripsi = $_POST['dekripsi'];
    $maker = $_POST['maker'];
    $errors = [];

    // Loop untuk menyimpan setiap item ke database
    for ($i = 0; $i < count($kodebarang); $i++) {
        $kode = mysqli_real_escape_string($conn, $kodebarang[$i]);
        $jenis = mysqli_real_escape_string($conn, $jenisbarang[$i]);
        $nama = mysqli_real_escape_string($conn, $namabarang[$i]);
        $deskripsi = mysqli_real_escape_string($conn, $dekripsi[$i]);
        $makerName = mysqli_real_escape_string($conn, $maker[$i]);

        // Cek apakah kode barang sudah ada
        $checkQuery = "SELECT * FROM master_barang WHERE kode_barang = '$kode'";
        $checkResult = mysqli_query($conn, $checkQuery);
        if (mysqli_num_rows($checkResult) > 0) {

            // Jika kode barang sudah ada, tambahkan pesan kesalahan
            $errors[] = "Kode barang '$kode' sudah ada. Silakan gunakan kode barang yang berbeda.";
        } else {

            // fungsi untuk menyimpan data ke database
            $query = "INSERT INTO master_barang (kode_barang, jenis_barang, nama_barang, deskripsi, maker) VALUES ('$kode', '$jenis', '$nama', '$deskripsi', '$makerName')";

            // Eksekusi query
            if (!mysqli_query($conn, $query)) {
                $errors[] = "Error: " . mysqli_error($conn);
            }
        }
    }
    if (!empty($errors)) {
        session_start();
        $_SESSION['errors'] = $errors;
        if (isset($_SESSION['role']) && $_SESSION['role'] == 'admin') {
            header("Location: ../admin/databarang");
        }
        exit();
    }
    // backlink setelah berhasil
    if (isset($_SESSION['role']) && $_SESSION['role'] == 'admin') {
        header("Location: ../admin/databarang");
    } else {
        header("Location: ../admin/databarang");
    }
    exit();
}
//                                                                              <== FORM BARANG MASTER SELESAI==>


//                                                                              <==FORM DI BARANG MASUK.PHP==>
if (isset($_POST['addnewbarangmasuk'])) {
    // Ambil data dari form
    $tanggal = mysqli_real_escape_string($conn, $_POST['tanggal']);
    $supplier = mysqli_real_escape_string($conn, $_POST['supplier']);
    $kodebarang = $_POST['kodebarang'];
    $jumlah = $_POST['jumlah'];
    $note = $_POST['note'];

    // Generate ID transaksi menggunakan timestamp atau ID unik lainnya
    $transaksi = "EMIX" . date("YmdHis");

    // Loop untuk menyimpan setiap item ke database
    for ($i = 0; $i < count($kodebarang); $i++) {
        $kode = mysqli_real_escape_string($conn, $kodebarang[$i]);
        $qty = mysqli_real_escape_string($conn, $jumlah[$i]);
        $catatan = mysqli_real_escape_string($conn, $note[$i]);

        // Perbarui query untuk menyimpan data barang masuk dengan transaksi ID
        $queryMasuk = "INSERT INTO barang_masuk (tanggal_masuk, supplier, kode_barang, jumlah_masuk, note, transaksi) 
                       VALUES ('$tanggal', '$supplier', '$kode', '$qty', '$catatan', '$transaksi')";

        // Eksekusi query untuk barang masuk
        if (mysqli_query($conn, $queryMasuk)) {
            // Update jumlah di tabel master_barang
            $updateQuery = "UPDATE master_barang SET jumlah = jumlah + $qty WHERE kode_barang = '$kode'";
            mysqli_query($conn, $updateQuery);
        } else {
            // Handle error
            echo "Error: " . mysqli_error($conn);
        }
    }

    // Redirect to appropriate page after form submission
    session_start(); // Ensure session is started
    if (isset($_SESSION['role']) && $_SESSION['role'] == 'admin') {
        header("Location: ../admin/masuk");
    } else {
        header("Location: ../user/masuk");
    }
    exit();
}

//                                                                                  <==Form Barang masuk Selesai==>

// UPDATE BARANG MASTER START
if (isset($_POST['update_barang'])) {
    $kode_barang_old = $_POST['kode_barang_old'];
    $kode_barang = $_POST['kode_barang'];
    $jenis_barang = $_POST['jenis_barang'];
    $nama_barang = $_POST['nama_barang'];
    $deskripsi = $_POST['deskripsi'];
    $maker = $_POST['maker'];
    $jumlah = $_POST['jumlah'];

    $query = "UPDATE master_barang
    SET kode_barang = '$kode_barang',
    jenis_barang = '$jenis_barang',
    nama_barang = '$nama_barang',
    deskripsi = '$deskripsi',
    maker = '$maker',
    jumlah = '$jumlah'
    WHERE kode_barang = '$kode_barang_old'";
    if (mysqli_query($conn, $query)) {
        header("Location: ../admin/databarang");
    }
    exit();
}
// UPDATE BARANG MASTER END

// HAPUS BARANG MASTER START
if (isset($_POST['delete_barang'])) {
    $kode_barang = $_POST['kode_barang'];

    $query = "DELETE FROM master_barang WHERE kode_barang = '$kode_barang'";
    if (mysqli_query($conn, $query)) {
        header("Location: ../admin/databarang");
    } else {
        echo "<script>
      alert('Gagal hapus barang');
    </script>";
    }
    exit();
}
// HAPUS BARANG KELUAR END



//                                                                                  <==FORM DI KELUAR.PHP==>
// FORM DI KELUAR.PHP
if (isset($_POST['addbarangkeluar'])) {
    session_start();
    $tanggal = $_POST['tanggal'];
    $user = $_POST['user'];
    $kodebarang = $_POST['kodebarang'];
    $jumlah = $_POST['jumlah'];
    $note = $_POST['note'];

    // Membuat ID transaksi unik dengan format: TRANSAKSI-TANGGAL-UNIK
    $transaksiId = "EMIX-" . date("YmdHis");

    for ($i = 0; $i < count($kodebarang); $i++) {
        $kode = mysqli_real_escape_string($conn, $kodebarang[$i]);
        $qty = mysqli_real_escape_string($conn, $jumlah[$i]);
        $catatan = mysqli_real_escape_string($conn, $note[$i]);

        // Simpan barang keluar dengan transaksi yang sudah dibuat
        $queryKeluar = "INSERT INTO barang_keluar 
                        (tanggal_keluar, user, kode_barang, jumlah_keluar, note, status_approve, transaksi) 
                        VALUES 
                        ('$tanggal', '$user', '$kode', '$qty', '$catatan', 'pending', '$transaksiId')";

        if (!mysqli_query($conn, $queryKeluar)) {
            echo "Error: " . mysqli_error($conn);
        }
    }

    // Redirect setelah berhasil menyimpan
    if ($_SESSION['role'] == 'admin') {
        header("Location: ../admin/keluar");
    } else {
        header("Location: ../user/keluar");
    }
    exit();
}


// Fungsi Untuk APPROVED BY 
if (isset($_POST['approveBarangKeluar'])) {
    $id_keluar = $_POST['id_keluar'];
    $kode_barang = $_POST['kode_barang'];
    $jumlah = $_POST['jumlah'];

    // Update status approve di tabel barang_keluar
    $approveQuery = "UPDATE barang_keluar SET status_approve = 'approved' WHERE id = '$id_keluar'";
    if (mysqli_query($conn, $approveQuery)) {
        // Kurangi stok barang di tabel master_barang
        $updateQuery = "UPDATE master_barang SET jumlah = jumlah - $jumlah WHERE kode_barang = '$kode_barang'";
        mysqli_query($conn, $updateQuery);

        // Redirect kembali ke halaman persetujuan
        header("Location: ../admin/keluar");
        exit();
    } else {
        echo "Error: " . mysqli_error($conn);
    }
}


//                                                                                 <==FORM BARANG KELUAR SELESAI==>
