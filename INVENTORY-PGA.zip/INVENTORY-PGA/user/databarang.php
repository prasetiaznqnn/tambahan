<?php
$title = "Data Barang | Elastomix";
require "../BackEnd/function.php";
require "layout/header.php";
session_start();


if (!isset($_SESSION['id']) || $_SESSION['role'] != 'user') {
    header("Location: ../index.php");
    exit();
}
?>
<main>
    <div class="container-fluid">
        <h1 class="mt-4">Data Master</h1>

        <a href="../export/export" style="color: white; text-decoration: none;"> <button style="border-radius: 10px;" class="btn btn-success">
                Ekspor Dokumen
            </button></a>
        <!-- tabel hasil data -->
        <div class="card mb-4 mt-2">

            <div class="card-header ">
                <i class="fas fa-table me-1"></i>TABEL MASTER DATA
            </div>
            <div class="card-body">

                <div class="table-responsive">
                    <table class="table table-hover table-striped table-bordered " id="dataTable" width="100%" cellspacing="0">
                        <thead>
                            <tr class="text-center">
                                <th>NO <i class="bi bi-airplane"></i></th>
                                <th>KODE BARANG</th>
                                <th>JENIS BARANG</th>
                                <th>NAMA BARANG</th>
                                <th>MAKER</th>
                                <th>JUMLAH</th>
                                <th>SATUAN</th>
                                <th>Tempat Penyimpanan</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            $ambilsemuastock = mysqli_query($conn, "SELECT * FROM  master_barang");
                            $i = 1;
                            while ($data = mysqli_fetch_array($ambilsemuastock)) {
                                $jenisBarang = $data['jenis_barang'];
                                $kbarang = $data['kode_barang'];
                                $namabarang = $data['nama_barang'];
                                $deskripsi = $data['deskripsi'];
                                $satuan = $data['satuan'];
                                $maker = $data['maker'];
                                $qty = $data['jumlah'];
                            ?>
                                <tr class="text-center">
                                    <td><?= $i++; ?></td>
                                    <td><?= $kbarang; ?></td>
                                    <td><?= $jenisBarang; ?></td>
                                    <td><?= $namabarang; ?></td>
                                    <td><?= $maker; ?></td>
                                    <td><?= $qty; ?></td>
                                    <td><?= $satuan; ?></td>
                                    <td><?= $deskripsi; ?></td>
                                </tr>
                            <?php
                            };
                            ?>
                        </tbody>
                    </table>
                </div>
            </div>

        </div>
    </div>
</main>
</div>
</div>

<?php include "../footer.php"; ?>